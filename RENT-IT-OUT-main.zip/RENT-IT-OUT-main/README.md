# RENT-IT-OUT
> e-commers website to give thinks in rent 
## Installation:
```sh
pip install uvicorn
```
**4.Run Server**
```sh
Python -m uvicorn server:app --reload
```

## Where to find Me
visit My [Website](https://sanjaysblog.netlify.app/)
